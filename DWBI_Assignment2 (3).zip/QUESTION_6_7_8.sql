
##QUESTION 6
use pubs;

select t.title ,count(ta.au_id) as No_of_authors from titles t 
inner join titleauthor ta on t.title_id=ta.title_id
group by t.title
having count(ta.au_id)>1;


##QUESTION7
select a.au_fname,a.au_lname,count(ta.title_id),from authors as a
join titleauthor as ta on a.au_id= ta.au_id
group by a.au_fname,a.au_lname
having count(ta.title_id)>1;

##QUESTION8
select p.pub_id,p.pub_name,t.title_id,t.title from publishers p
join titles t on p.pub_id=t.pub_id
group by p.pub_id,pub_name,t.title_id,t.title
having count(t.title_id)=0;



