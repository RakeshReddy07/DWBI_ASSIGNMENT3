USE [AdventureWorks2012]
GO
select * from HumanResources.Employee;
ALTER TABLE HumanResources.Employee
DROP CONSTRAINT [CK_Employee_Gender];


INSERT INTO [HumanResources].[Employee]
([BusinessEntityID],[NationalIDNumber],[LoginID],[OrganizationNode],[JobTitle],[BirthDate],[MaritalStatus],
[Gender],[HireDate],[SalariedFlag],[VacationHours],[SickLeaveHours],[CurrentFlag],[rowguid],[ModifiedDate])
VALUES(297,483055938,'adventure-works\anurag0',0x95EF,'Sales Representative','1968-03-12','S','G','2012-05-28'
,1,37,36,1,'623213F9-DD0F-43B4-BDD2-C96E93D3F4BF','2014-06-30')

select * from HumanResources.Employee;
select * from Outp3;

